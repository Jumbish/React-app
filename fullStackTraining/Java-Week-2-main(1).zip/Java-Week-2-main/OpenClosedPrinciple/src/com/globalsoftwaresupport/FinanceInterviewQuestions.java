package com.globalsoftwaresupport;

public class FinanceInterviewQuestions implements InterviewQuestion {

	@Override
	public void execute() {
		System.out.println("Quantitative finance related questions...");
	}
}
