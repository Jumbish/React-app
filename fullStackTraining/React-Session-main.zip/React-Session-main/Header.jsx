import React from 'react'
import './Header.css';
function Header() {
  return (
    <div class="header">
        <h1>Header of my Page</h1>
    </div>
  )
}

export default Header