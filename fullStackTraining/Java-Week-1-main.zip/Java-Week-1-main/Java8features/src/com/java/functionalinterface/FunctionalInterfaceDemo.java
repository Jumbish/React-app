package com.java.functionalinterface;
@FunctionalInterface
public interface FunctionalInterfaceDemo {
	public void square(int x);
	
}
