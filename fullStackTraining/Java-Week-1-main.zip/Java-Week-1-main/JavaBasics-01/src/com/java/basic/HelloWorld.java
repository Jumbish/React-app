package com.java.basic;

public class HelloWorld {
	static int x = 10;
	static String name="Java";
	public static void main(String[] args) {
		
		
		
		System.out.println("--Welcome to java World--");
		System.out.println(HelloWorld.name);
		System.out.println(HelloWorld.x);
		System.out.println(name instanceof String);
		
	}

}
