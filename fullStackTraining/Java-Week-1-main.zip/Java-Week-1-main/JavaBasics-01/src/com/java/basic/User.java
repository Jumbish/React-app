package com.java.basic;

public class User {
 int userid;
 String username;
}
