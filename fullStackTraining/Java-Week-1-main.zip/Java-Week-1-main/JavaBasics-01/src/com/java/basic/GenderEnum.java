package com.java.basic;

public enum GenderEnum {
MALE,FEMALE,TRANSGENDER
}
