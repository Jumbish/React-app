package com.globalsoftwaresupport;

public class Operation {

	public static int execute(int num1, int num2) {
		return num1*num2;
	}
}
