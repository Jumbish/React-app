package com.globalsoftwaresupport;

public interface Tree {
	public void insert();
	public void delete();
	public void traverse();
}
