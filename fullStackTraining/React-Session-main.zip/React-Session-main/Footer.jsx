import React from 'react'
import './Footer.css'
function Footer() {
  return (
    <div className="footer">
        <h2>@Copyright:abc@gmail.com</h2>
        <h2>Contact No:98765412</h2>
    </div>
  )
}

export default Footer